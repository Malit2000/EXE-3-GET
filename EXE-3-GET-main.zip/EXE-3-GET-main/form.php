<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP GET Method Example</title>
    <link rel="stylesheet" href="form.css">
</head>
<body>
    <?php
        $name = isset($_GET['name']) ? htmlspecialchars($_GET['name']) : '';
        $email = isset($_GET['email']) ? htmlspecialchars($_GET['email']) : '';
        $age = isset($_GET['age']) ? (int)$_GET['age'] : 0;
        $city = isset($_GET['city']) ? htmlspecialchars($_GET['city']) : '';
        $submitted = !empty($_GET);
    ?>

    <div class="container">
        <h1>PHP GET Method Example</h1>
        
        <div class="info-box">
            <strong>About GET Method:</strong> The GET method sends form data as URL parameters. 
            It's visible in the URL and suitable for non-sensitive data like search queries or filters.
        </div>

        <form method="GET" action="">
            <div class="form-group">
                <label for="name">Full Name:</label>
                <input type="text" id="name" name="name" placeholder="Enter your full name" value="<?php echo $name; ?>">
            </div>
            
            <div class="form-group">
                <label for="email">Email Address:</label>
                <input type="email" id="email" name="email" placeholder="Enter your email" value="<?php echo $email; ?>">
            </div>
            
            <div class="form-group">
                <label for="age">Age:</label>
                <input type="number" id="age" name="age" placeholder="Enter your age" min="1" max="120" value="<?php echo $age > 0 ? $age : ''; ?>">
            </div>
            
            <div class="form-group">
                <label for="city">City:</label>
                <input type="text" id="city" name="city" placeholder="Enter your city" value="<?php echo $city; ?>">
            </div>
            
            <button type="submit" class="btn">Submit Form</button>
            <button type="reset" class="btn btn-clear" onclick="window.location.href=window.location.pathname;">Clear Form</button>
        </form>

        <?php if ($submitted): ?>
            <div class="result">
                <h2>Form Data Received via GET Method:</h2>
                <p><strong>Name:</strong> <?php echo $name ? $name : 'Not provided'; ?></p>
                <p><strong>Email:</strong> <?php echo $email ? $email : 'Not provided'; ?></p>
                <p><strong>Age:</strong> <?php echo $age > 0 ? $age . ' years old' : 'Not provided'; ?></p>
                <p><strong>City:</strong> <?php echo $city ? $city : 'Not provided'; ?></p>
                <h3>Current URL with GET Parameters:</h3>
                <div class="url-display">
                    <?php echo htmlspecialchars($_SERVER['REQUEST_URI']); ?>
                </div>
                <h3>All GET Data:</h3>
                <div class="url-display">
                    <?php
                    foreach ($_GET as $key => $value) {
                        echo htmlspecialchars($key) . " = " . htmlspecialchars($value) . "<br>";
                    }
                    ?>
                </div>
            </div>
        <?php else: ?>
            <div class="result">
                <h2>No data submitted.</h2>
                <p>Please fill out the form above.</p>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
